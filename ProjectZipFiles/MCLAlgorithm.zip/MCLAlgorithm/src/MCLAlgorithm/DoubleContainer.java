package MCLAlgorithm; 

public class DoubleContainer {
    final double[] c;

    public DoubleContainer(int size) {
        this.c = new double[size];
    }      
}
