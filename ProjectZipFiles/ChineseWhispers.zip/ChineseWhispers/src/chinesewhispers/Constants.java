package chinesewhispers;

public class Constants {
    final public static int SLOT_POW2=12;
    final public static int SLOT_POW2_MASK=(1<<SLOT_POW2)-1;
}
