package MCLAlgorithm; 

public class IntContainer {
    final int[] c;

    public IntContainer(int size) {
        this.c = new int[size];
    }
}
