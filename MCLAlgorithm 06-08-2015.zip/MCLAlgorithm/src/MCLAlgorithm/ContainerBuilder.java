package MCLAlgorithm; 

public interface ContainerBuilder<T> {
    public T build(int dimension);
}
